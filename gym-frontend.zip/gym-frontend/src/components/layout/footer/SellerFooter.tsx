import type { LucideIcon } from 'lucide-react'
import {
  BadgeCheck,
  BarChart3,
  ClipboardList,
  FileText,
  Flag,
  Headphones,
  LifeBuoy,
  LockKeyhole,
  Package,
  RotateCcw,
  ScrollText,
  ShieldCheck,
  Store,
  Truck,
} from 'lucide-react'
 
type FooterLink = {
  label: string
  href: string
  icon: LucideIcon
}

type Commitment = {
  label: string
  icon: LucideIcon
}

const socialLogos = {
  facebook: '/facebook.png',
  zalo: '/zalo.png',
  instagram: '/instagram.png',
}

function SellerFooter() {
  const currentYear = new Date().getFullYear()

  const commitments: Commitment[] = [
    { label: 'Hàng chính hãng 100%', icon: ShieldCheck },
    { label: 'Giao hàng toàn quốc', icon: Truck },
    { label: 'Thanh toán an toàn', icon: LockKeyhole },
    { label: 'Đổi trả miễn phí', icon: RotateCcw },
  ]

  const sellerLinks: FooterLink[] = [
    { label: 'Quản lý sản phẩm', href: '/seller/products', icon: Package },
    { label: 'Quản lý đơn hàng', href: '/seller/orders', icon: ClipboardList },
    { label: 'Doanh thu', href: '/seller/revenue', icon: BarChart3 },
    { label: 'Chính sách', href: '/seller/policy', icon: ScrollText },
  ]

  const supportLinks: FooterLink[] = [
    { label: 'Trung tâm trợ giúp', href: '/support/help-center', icon: LifeBuoy },
    { label: 'Liên hệ', href: '/support/contact', icon: Headphones },
    { label: 'Báo cáo', href: '/support/report', icon: Flag },
    { label: 'Điều khoản', href: '/terms', icon: FileText },
  ]

  const renderLink = (item: FooterLink) => {
    const Icon = item.icon

    return (
      <a
        key={item.label}
        href={item.href}
        className="group flex items-center gap-2 text-sm transition-colors hover:text-[var(--gs-text)]"
        style={{ color: 'var(--gs-muted)' }}
      >
        <Icon className="h-4 w-4 shrink-0 transition-colors group-hover:text-[var(--gs-text)]" style={{ color: 'var(--gs-muted)' }} />
        <span>{item.label}</span>
      </a>
    )
  }

  return (
    <footer
      className="w-full border-t"
      style={{ background: 'var(--theme-card)', color: 'var(--theme-text)', borderColor: 'var(--theme-border)' }}
    >
      <section
        className="border-b px-5 py-7 md:px-8"
        style={{ background: 'var(--theme-card)', color: 'var(--theme-text)', borderColor: 'var(--theme-border)' }}
      >
        <div className="w-full">
          <h2 className="text-center text-xl font-extrabold md:text-2xl">
            {'Cam kết từ GymPro'}
          </h2>
          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {commitments.map((item) => {
              const Icon = item.icon

              return (
                <div
                  key={item.label}
                  className="flex min-h-20 items-center gap-3 rounded-2xl border p-4 shadow-sm"
                  style={{ background: 'var(--theme-elevated)', color: 'var(--theme-text)', borderColor: 'var(--theme-border)' }}
                >
                  <span
                    className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl"
                    style={{ background: 'var(--theme-button-bg)', color: 'var(--theme-button-text)' }}
                  >
                    <Icon className="h-5 w-5" />
                  </span>
                  <span className="text-sm font-bold leading-5">{item.label}</span>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      <section className="px-5 py-10 md:px-8 md:py-12">
        <div className="grid w-full gap-9 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <div className="flex items-center gap-3">
              <span
                className="flex h-12 w-12 items-center justify-center rounded-2xl"
                style={{ background: 'var(--theme-button-bg)', color: 'var(--theme-button-text)' }}
              >
                <Store className="h-6 w-6" />
              </span>
              <div>
                <p className="text-lg font-extrabold leading-tight" style={{ color: 'var(--theme-accent)' }}>GymPro Seller</p>
                <p className="text-sm" style={{ color: 'var(--gs-muted)' }}>
                  {'Nền tảng bán hàng thể thao'}
                </p>
              </div>
            </div>
            <p className="mt-5 text-sm leading-6" style={{ color: 'var(--gs-muted)' }}>
              {'Đồng hành cùng bạn trên con đường kinh doanh thể thao.'}
            </p>
          </div>

          <div>
            <h3 className="text-sm font-bold uppercase tracking-[0.2em]" style={{ color: 'var(--gs-text)' }}>
              {'Dành cho người bán'}
            </h3>
            <div className="mt-5 space-y-3">{sellerLinks.map(renderLink)}</div>
          </div>

          <div>
            <h3 className="text-sm font-bold uppercase tracking-[0.2em]" style={{ color: 'var(--gs-text)' }}>
              {'Hỗ trợ'}
            </h3>
            <div className="mt-5 space-y-3">{supportLinks.map(renderLink)}</div>
          </div>

          <div>
            <h3 className="text-sm font-bold uppercase tracking-[0.2em]" style={{ color: 'var(--gs-text)' }}>
              {'Kết nối'}
            </h3>
            <div className="mt-5 flex items-center gap-3">
              <a
                href="https://facebook.com"
                aria-label="Facebook"
                target="_blank"
                rel="noreferrer"
                className="flex h-10 w-10 items-center justify-center rounded-xl bg-transparent transition-transform duration-150 hover:scale-110"
                style={{ color: '#1877f2' }}
              >
                <img src={socialLogos.facebook} alt="" className="h-8 w-8 object-contain" />
              </a>
              <a
                href="https://zalo.me"
                aria-label="Zalo"
                target="_blank"
                rel="noreferrer"
                className="flex h-10 w-10 items-center justify-center rounded-xl bg-transparent transition-transform duration-150 hover:scale-110"
                style={{ color: '#0068ff' }}
              >
                <img src={socialLogos.zalo} alt="" className="h-9 w-9 object-contain" />
              </a>
              <a
                href="https://instagram.com"
                aria-label="Instagram"
                target="_blank"
                rel="noreferrer"
                className="flex h-10 w-10 items-center justify-center rounded-xl bg-transparent transition-transform duration-150 hover:scale-110"
                style={{ color: '#e4405f' }}
              >
                <img src={socialLogos.instagram} alt="" className="h-8 w-8 object-contain" />
              </a>
            </div>
          </div>
        </div>
      </section>

      <div
        className="border-t px-5 py-5 md:px-8"
        style={{ borderColor: 'var(--theme-border)' }}
      >
        <div className="flex w-full flex-col gap-2 text-sm md:flex-row md:items-center md:justify-between" style={{ color: 'var(--gs-muted)' }}>
          <p>{`© ${currentYear} GymPro Seller. Đã đăng ký bản quyền.`}</p>
          <p className="flex items-center gap-2 font-semibold" style={{ color: 'var(--gs-text)' }}>
            <BadgeCheck className="h-4 w-4" style={{ color: 'var(--theme-accent)' }} />
            {'Đã được xác thực'}
          </p>
        </div>
      </div>
    </footer>
  )
}

export default SellerFooter
