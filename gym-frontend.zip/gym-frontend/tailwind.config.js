export default {
  darkMode: 'class',
}
