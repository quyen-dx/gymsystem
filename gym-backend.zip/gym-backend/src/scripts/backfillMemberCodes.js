import mongoose from 'mongoose'
import User from '../models/User.js'
import connectDB from '../config/db.js'

async function backfillMemberCodes() {
  await connectDB()

  const users = await User.find({})
    .sort({ createdAt: 1 })
    .select('_id memberCode memberNumber name email createdAt')
    .lean()

  console.log(`Found ${users.length} users, sorted by createdAt ASC:\n`)

  // Phase 1: clear all member identifiers to avoid unique index conflicts
  const ids = users.map((u) => u._id)
  await User.updateMany({ _id: { $in: ids } }, { $unset: { memberCode: '', memberNumber: '' } })
  console.log('  Phase 1: cleared all memberCodes and memberNumbers\n')

  // Phase 2: assign GP1, GP2, ... in createdAt order
  for (const [index, user] of users.entries()) {
    const memberNumber = index + 1
    const newCode = `GP${memberNumber}`
    await User.updateOne({ _id: user._id }, { $set: { memberCode: newCode, memberNumber } })
    console.log(`  ${String(memberNumber).padStart(2)}. ${newCode}  |  ${user.name || user.email}`)
  }

  console.log(`\n✅ Updated ${users.length} users successfully`)
  process.exit(0)
}

backfillMemberCodes().catch((err) => {
  console.error(err)
  process.exit(1)
})
